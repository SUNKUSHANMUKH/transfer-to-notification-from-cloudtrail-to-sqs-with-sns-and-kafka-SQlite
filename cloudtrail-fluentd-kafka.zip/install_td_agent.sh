#!/bin/bash
# Run on Amazon Linux 2 (EC2) as root or with sudo
set -euo pipefail

echo "Installing td-agent (Fluentd) and required plugins..."
curl -L https://toolbelt.treasuredata.com/sh/install-amazon2-td-agent4.sh | sh

# Install Fluentd plugins for S3, SQS, Kafka
/usr/sbin/td-agent-gem install fluent-plugin-s3
/usr/sbin/td-agent-gem install fluent-plugin-kafka
/usr/sbin/td-agent-gem install fluent-plugin-sqs

echo "Create directory for TLS certs (if needed): /etc/td-agent/certs"
mkdir -p /etc/td-agent/certs
echo "Installation complete. Copy td-agent.conf to /etc/td-agent/td-agent.conf and start the service."
