# CloudTrail -> SQS -> Fluentd (EC2) -> Kafka
This archive contains configuration files and helper scripts to implement the pipeline described:
CloudTrail (S3) -> SQS -> Fluentd (td-agent on EC2) -> Kafka.

**Files included**
- td-agent.conf                 : Fluentd (td-agent) configuration (placeholders included)
- install_td_agent.sh           : Script to install td-agent and plugins on Amazon Linux 2
- sqs_policy.json               : Example SQS queue policy for CloudTrail notifications
- start_td_agent.sh             : Start/enable td-agent systemd service
- kafka_consumer_test.sh        : Simple consumer command example for testing (needs Kafka tools)
- README.md                     : This file

**Important**
- Replace all placeholders in `td-agent.conf` with your real values:
  `<YOUR_SQS_QUEUE_URL>`, `<YOUR_AWS_REGION>`, `<YOUR_CLOUDTRAIL_BUCKET_NAME>`,
  `<YOUR_KAFKA_BOOTSTRAP_BROKERS>`, `<YOUR_SASL_USERNAME>`, `<YOUR_SASL_PASSWORD>`, etc.
- Do NOT commit secrets. Use AWS IAM roles for the EC2 instance whenever possible.
- This archive is a helper — adapt to your environment, security, and operational requirements.

