#!/bin/bash
# Start and enable td-agent systemd service
sudo systemctl daemon-reload || true
sudo systemctl enable td-agent
sudo systemctl start td-agent
sudo journalctl -u td-agent -f
