#!/bin/bash
# Example: consume from the topic to verify messages are arriving.
# Requires Kafka tools (kafka-console-consumer.sh) available on the host or in PATH.
# Replace <YOUR_BROKERS> and topic as needed.
BROKERS="<YOUR_KAFKA_BOOTSTRAP_BROKERS>"
TOPIC="aws-cloudtrail-logs"
echo "Consuming from topic ${TOPIC}..."
./kafka-console-consumer.sh --bootstrap-server "${BROKERS}" --topic "${TOPIC}" --from-beginning
